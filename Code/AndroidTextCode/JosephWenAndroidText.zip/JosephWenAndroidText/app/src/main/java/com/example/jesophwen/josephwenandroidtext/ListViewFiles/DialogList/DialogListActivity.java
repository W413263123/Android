package com.example.jesophwen.josephwenandroidtext.ListViewFiles.DialogList;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.jesophwen.josephwenandroidtext.BaseFiles.BaseActivity;
import com.example.jesophwen.josephwenandroidtext.BaseFiles.TitleLayout;
import com.example.jesophwen.josephwenandroidtext.R;

public class DialogListActivity extends BaseActivity {
    static EditText messageEditText;  // 发送消息输入框
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_list);
        TitleLayout title = (TitleLayout)findViewById(R.id.dialog_list_title);
        title.titleTextView.setText("DialogList");
        /** 实例化消息输入框 */
        messageEditText = (EditText)findViewById(R.id.message_edit_text);
    }

    /** 发送按钮点击事件 */
    public void sendButtonAction(View v) {

    }
}

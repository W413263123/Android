package com.example.jesophwen.josephwenandroidtext.ListViewFiles.DialogList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

/**
 * Created by wenkui on 16/9/21.
 */

public class DialogListAdapter extends ArrayAdapter<Message> {
    static int resourceId;
    public DialogListAdapter(Context context, int resourceItemId, List<Message> objects) {
        super(context, resourceItemId, objects);

        resourceId = resourceItemId;
    }

    @Override
    public View getView( int position, View converView, ViewGroup group) {
        /** 获取模型对象 */
        Message message = (Message)getItem(position);
        View view;
        if (converView == null) {
            view = LayoutInflater.from(getContext()).inflate(resourceId, null);
        }else {
            view = converView;

        }

        return view;
    }


    class ViewHelpler {

    }
}
